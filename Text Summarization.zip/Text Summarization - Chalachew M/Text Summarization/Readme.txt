Using Jupyter Notebook
1. run each cell
2. in the choice cell choose either of
   . from keyboard or copy pase
   . from .txt file use example am.txt
   . from .pdf summariza from pdf
   . from Wikipedia
End

   